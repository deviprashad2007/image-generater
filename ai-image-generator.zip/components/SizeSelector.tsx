"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

const SizeSelector: React.FC = () => {
  const { size, setSize } = useGenerator()

  return (
    <div>
      <Label htmlFor="size">Size</Label>
      <Select value={size} onValueChange={setSize}>
        <SelectTrigger id="size">
          <SelectValue placeholder="Select image size" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="256x256">256x256</SelectItem>
          <SelectItem value="512x512">512x512</SelectItem>
          <SelectItem value="1024x1024">1024x1024</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}

export default SizeSelector

