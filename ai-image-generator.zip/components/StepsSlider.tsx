"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"

const StepsSlider: React.FC = () => {
  const { steps, setSteps } = useGenerator()

  return (
    <div>
      <Label htmlFor="steps">Generation Steps: {steps}</Label>
      <Slider id="steps" min={10} max={150} step={1} value={[steps]} onValueChange={(value) => setSteps(value[0])} />
    </div>
  )
}

export default StepsSlider

