"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const PromptInput: React.FC = () => {
  const { prompt, setPrompt } = useGenerator()

  return (
    <div>
      <Label htmlFor="prompt">Prompt</Label>
      <Input
        id="prompt"
        placeholder="Describe the image you want to generate..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
    </div>
  )
}

export default PromptInput

