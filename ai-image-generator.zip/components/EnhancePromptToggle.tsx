"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

const EnhancePromptToggle: React.FC = () => {
  const { enhancePrompt, setEnhancePrompt } = useGenerator()

  return (
    <div className="flex items-center space-x-2">
      <Switch id="enhance-prompt" checked={enhancePrompt} onCheckedChange={setEnhancePrompt} />
      <Label htmlFor="enhance-prompt">Enhance Prompt</Label>
    </div>
  )
}

export default EnhancePromptToggle

