"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const NegativePromptInput: React.FC = () => {
  const { negativePrompt, setNegativePrompt } = useGenerator()

  return (
    <div>
      <Label htmlFor="negative-prompt">Negative Prompt</Label>
      <Input
        id="negative-prompt"
        placeholder="Describe what you don't want in the image..."
        value={negativePrompt}
        onChange={(e) => setNegativePrompt(e.target.value)}
      />
    </div>
  )
}

export default NegativePromptInput

