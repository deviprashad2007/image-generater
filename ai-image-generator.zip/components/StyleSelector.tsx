"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

const StyleSelector: React.FC = () => {
  const { style, setStyle } = useGenerator()

  return (
    <div>
      <Label htmlFor="style">Style</Label>
      <Select value={style} onValueChange={setStyle}>
        <SelectTrigger id="style">
          <SelectValue placeholder="Select a style" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="photorealistic">Photorealistic</SelectItem>
          <SelectItem value="cartoon">Cartoon</SelectItem>
          <SelectItem value="anime">Anime</SelectItem>
          <SelectItem value="digital-art">Digital Art</SelectItem>
          <SelectItem value="oil-painting">Oil Painting</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}

export default StyleSelector

