"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import PromptInput from "./PromptInput"
import StyleSelector from "./StyleSelector"
import SizeSelector from "./SizeSelector"
import NegativePromptInput from "./NegativePromptInput"
import StepsSlider from "./StepsSlider"
import SeedInput from "./SeedInput"
import EnhancePromptToggle from "./EnhancePromptToggle"
import GenerateButton from "./GenerateButton"
import ImageDisplay from "./ImageDisplay"

const GeneratorUI: React.FC = () => {
  const { isGenerating } = useGenerator()

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="space-y-6">
        <PromptInput />
        <StyleSelector />
        <SizeSelector />
        <NegativePromptInput />
        <StepsSlider />
        <SeedInput />
        <EnhancePromptToggle />
        <GenerateButton />
      </div>
      <ImageDisplay />
    </div>
  )
}

export default GeneratorUI

