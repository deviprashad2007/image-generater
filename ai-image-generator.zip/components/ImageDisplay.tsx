"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import { Button } from "@/components/ui/button"
import { Download, RefreshCw } from "lucide-react"
import Image from "next/image"

const ImageDisplay: React.FC = () => {
  const { generatedImage, setIsGenerating, setGeneratedImage } = useGenerator()

  const handleRegenerate = () => {
    setIsGenerating(true)
    // Simulating image regeneration
    setTimeout(() => {
      setGeneratedImage("/placeholder.svg?height=512&width=512")
      setIsGenerating(false)
    }, 3000)
  }

  return (
    <div className="space-y-4">
      {generatedImage ? (
        <div className="relative aspect-square">
          <Image
            src={generatedImage || "/placeholder.svg"}
            alt="Generated image"
            layout="fill"
            objectFit="cover"
            className="rounded-lg"
          />
        </div>
      ) : (
        <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
          <p className="text-gray-500">Your generated image will appear here</p>
        </div>
      )}
      {generatedImage && (
        <div className="flex space-x-2">
          <Button variant="outline" className="w-full">
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
          <Button variant="outline" className="w-full" onClick={handleRegenerate}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Regenerate
          </Button>
        </div>
      )}
    </div>
  )
}

export default ImageDisplay

