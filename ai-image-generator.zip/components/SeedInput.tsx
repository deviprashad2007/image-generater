"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const SeedInput: React.FC = () => {
  const { seed, setSeed } = useGenerator()

  return (
    <div>
      <Label htmlFor="seed">Seed (optional)</Label>
      <Input
        id="seed"
        placeholder="Enter a seed for reproducible results"
        value={seed}
        onChange={(e) => setSeed(e.target.value)}
      />
    </div>
  )
}

export default SeedInput

