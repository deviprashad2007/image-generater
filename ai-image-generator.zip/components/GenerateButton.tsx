"use client"

import type React from "react"
import { useGenerator } from "../context/GeneratorContext"
import { AuroraButton } from "@/components/ui/aurora-button"
import { Loader2 } from "lucide-react"

const GenerateButton: React.FC = () => {
  const { prompt, isGenerating, setIsGenerating, setGeneratedImage } = useGenerator()

  const handleGenerate = async () => {
    setIsGenerating(true)
    // Simulating image generation
    await new Promise((resolve) => setTimeout(resolve, 3000))
    setGeneratedImage("/placeholder.svg?height=512&width=512")
    setIsGenerating(false)
  }

  return (
    <AuroraButton
      onClick={handleGenerate}
      disabled={isGenerating || !prompt}
      className="w-full py-3 text-lg font-semibold"
      glowClassName="from-purple-600 via-pink-600 to-blue-600"
    >
      {isGenerating ? (
        <>
          <Loader2 className="mr-2 h-5 w-5 animate-spin inline-block" />
          Generating...
        </>
      ) : (
        "Generate Image"
      )}
    </AuroraButton>
  )
}

export default GenerateButton

