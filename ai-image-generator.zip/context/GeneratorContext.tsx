"use client"

import type React from "react"
import { createContext, useContext, useState, type ReactNode } from "react"

interface GeneratorContextType {
  prompt: string
  setPrompt: (prompt: string) => void
  style: string
  setStyle: (style: string) => void
  size: string
  setSize: (size: string) => void
  negativePrompt: string
  setNegativePrompt: (negativePrompt: string) => void
  steps: number
  setSteps: (steps: number) => void
  seed: string
  setSeed: (seed: string) => void
  enhancePrompt: boolean
  setEnhancePrompt: (enhancePrompt: boolean) => void
  isGenerating: boolean
  setIsGenerating: (isGenerating: boolean) => void
  generatedImage: string
  setGeneratedImage: (generatedImage: string) => void
}

const GeneratorContext = createContext<GeneratorContextType | undefined>(undefined)

export const useGenerator = () => {
  const context = useContext(GeneratorContext)
  if (!context) {
    throw new Error("useGenerator must be used within a GeneratorProvider")
  }
  return context
}

export const GeneratorProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [prompt, setPrompt] = useState("")
  const [style, setStyle] = useState("photorealistic")
  const [size, setSize] = useState("1024x1024")
  const [negativePrompt, setNegativePrompt] = useState("")
  const [steps, setSteps] = useState(30)
  const [seed, setSeed] = useState("")
  const [enhancePrompt, setEnhancePrompt] = useState(true)
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedImage, setGeneratedImage] = useState("")

  return (
    <GeneratorContext.Provider
      value={{
        prompt,
        setPrompt,
        style,
        setStyle,
        size,
        setSize,
        negativePrompt,
        setNegativePrompt,
        steps,
        setSteps,
        seed,
        setSeed,
        enhancePrompt,
        setEnhancePrompt,
        isGenerating,
        setIsGenerating,
        generatedImage,
        setGeneratedImage,
      }}
    >
      {children}
    </GeneratorContext.Provider>
  )
}

