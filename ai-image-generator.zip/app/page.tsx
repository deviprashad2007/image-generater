import { GeneratorProvider } from "../context/GeneratorContext"
import Header from "../components/Header"
import GeneratorUI from "../components/GeneratorUI"
import { Pricing } from "../components/Pricing"

const pricingPlans = [
  {
    name: "Basic",
    price: "9",
    yearlyPrice: "90",
    period: "month",
    features: [
      "100 AI-generated images per month",
      "Basic editing tools",
      "Standard resolution output",
      "Email support",
    ],
    description: "Perfect for hobbyists and casual users.",
    buttonText: "Get Started",
    href: "/signup?plan=basic",
    isPopular: false,
  },
  {
    name: "Pro",
    price: "29",
    yearlyPrice: "290",
    period: "month",
    features: [
      "500 AI-generated images per month",
      "Advanced editing tools",
      "High-resolution output",
      "Priority email support",
      "Access to beta features",
    ],
    description: "Ideal for professionals and small businesses.",
    buttonText: "Go Pro",
    href: "/signup?plan=pro",
    isPopular: true,
  },
  {
    name: "Enterprise",
    price: "99",
    yearlyPrice: "990",
    period: "month",
    features: [
      "Unlimited AI-generated images",
      "Full suite of editing tools",
      "Ultra-high resolution output",
      "24/7 priority support",
      "API access",
      "Custom integrations",
    ],
    description: "For large-scale use and custom needs.",
    buttonText: "Contact Sales",
    href: "/contact-sales",
    isPopular: false,
  },
]

export default function Home() {
  return (
    <GeneratorProvider>
      <div className="min-h-screen bg-gradient-to-b from-gray-100 to-gray-200 dark:from-gray-900 dark:to-gray-800">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <GeneratorUI />
          <Pricing
            plans={pricingPlans}
            title="Choose Your AI Image Generation Plan"
            description="Unlock the power of AI-generated images with our flexible pricing options."
          />
        </main>
      </div>
    </GeneratorProvider>
  )
}

